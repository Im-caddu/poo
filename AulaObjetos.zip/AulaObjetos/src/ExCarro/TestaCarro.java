package ExCarro;

public class TestaCarro {

	public static void main(String[] args) {
		//Criando um objeto da classe carro (instanciação)
		Carro carro1 = new Carro("Toyota", "Corolla", 2020);
		Carro carro2 = new Carro("Ford", "Mustang", 2013);
		Carro carro3 = new Carro("Honda", "Civic", 2025);
		
		//Exibindo informações do carro
		System.out.println("Informações do carro (objeto 01):");
		carro1.exibirInformacoes();
		
		//Ligando o carro
		System.out.println("\nLigando o carro... (objeto 01):");
		carro1.ligar();
		
		System.out.println("\nInformações do carro (objeto 01):");
		carro1.exibirInformacoes();
		
		System.out.println("\nInformações do carro (objeto 02):");
		carro2.exibirInformacoes();
		
		System.out.println("\nLigando o carro... (objeto 02):");
		carro2.ligar();
		
		System.out.println("\nInformações do carro (objeto 02):");
		carro2.exibirInformacoes();
		
		//Desligando o carro
		System.out.println("\nDesligando o carro... (objeto 01):");
		carro1.desligar();
		
		//Exibindo informações finais do carro
		System.out.println("\nInformações do carro após desligar (objeto 01):");
		carro1.exibirInformacoes();
		

	}

}
