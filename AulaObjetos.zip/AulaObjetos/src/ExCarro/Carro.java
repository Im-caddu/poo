package ExCarro;

//Definição da classe carro
public class Carro {
	//Atributos (propriedades, características) do carro
	String marca;
	String modelo;
	int ano;
	boolean ligado;
	
	//Método construtor (inicializa o objeto)
	public Carro(String marca, String modelo, int ano) {
		this.marca = marca;
		this.modelo = modelo;
		this.ano = ano;
		this.ligado = false; //Por padrão, o carro começa desligado
	}
	
	//Método para ligar o carro
	public void ligar() {
		if (!ligado) {
			ligado = true;
			System.out.println("O carro está ligado!");
		} else {
			System.out.println("O carro está desligado!");
		}
	}
	
	//Método para desligar o carro
	public void desligar() {
		if (ligado) {
			ligado = false;
			System.out.println("O carro está desligado!");
		} else {
			System.out.println("O carro está ligado!");
		}
	}
	
	//Método para exibir informações do carro
	public void exibirInformacoes() {
		System.out.println("Marca: " + marca +"\nModelo: " + modelo + "\nAno: " + ano + "\nStatus: " + (ligado? "Ligado" : "Desligado"));
	}
}
